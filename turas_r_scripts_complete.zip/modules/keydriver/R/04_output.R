# ==============================================================================
# KEY DRIVER OUTPUT WRITER
# ==============================================================================
#
# Version: Turas v10.3 (Continuous Key Driver Upgrade)
# Date: 2025-12
#
# NEW IN v10.3:
#   - Status table with run_status per spec
#   - Method notes per driver
#   - Enhanced output contract compliance
#
# ==============================================================================

#' Calculate VIF (Variance Inflation Factor)
#' @keywords internal
calculate_vif <- function(model) {
  # Get model matrix (excluding intercept)
  X <- stats::model.matrix(model)[, -1, drop = FALSE]

  # VIF is only defined when there are at least 2 predictor terms
  if (ncol(X) < 2) {
    # Return NULL - VIF cannot be calculated with < 2 predictors
    # This is not an error, just means multicollinearity check is not applicable
    return(NULL)
  }

  # Calculate VIF for each predictor
  vif_vals <- numeric(ncol(X))
  names(vif_vals) <- colnames(X)

  for (i in seq_len(ncol(X))) {
    # Regress predictor i on all other predictors
    r_squared <- summary(stats::lm(X[, i] ~ X[, -i]))$r.squared
    vif_vals[i] <- 1 / (1 - r_squared)
  }

  vif_vals
}


#' Write Key Driver Results to Excel
#'
#' @param importance Importance data frame
#' @param model Fitted model
#' @param correlations Correlation matrix
#' @param config Configuration list
#' @param output_file Output file path
#' @param run_status TRS run status (PASS, PARTIAL)
#' @param status_details Optional list with status details
#' @keywords internal
write_keydriver_output <- function(importance, model, correlations, config, output_file,
                                    run_status = "PASS", status_details = NULL) {

  wb <- openxlsx::createWorkbook()

  # Header style
  header_style <- openxlsx::createStyle(
    fontSize = 11,
    fontColour = "#FFFFFF",
    fgFill = "#4472C4",
    halign = "left",
    valign = "center",
    textDecoration = "bold",
    border = "TopBottomLeftRight"
  )

  # ----------------------------------------------------------------------
  # Sheet 1: Importance Summary
  # ----------------------------------------------------------------------
  openxlsx::addWorksheet(wb, "Importance Summary")

  summary_cols <- c("Driver", "Label", "Shapley_Value", "Relative_Weight",
                    "Beta_Weight", "Beta_Coefficient", "Correlation", "Average_Rank")

  if (all(summary_cols %in% names(importance))) {
    summary_data <- importance[, summary_cols, drop = FALSE]
    names(summary_data) <- c("Driver", "Label", "Shapley (%)", "Rel. Weight (%)",
                             "Beta Weight (%)", "Beta Coef", "Correlation (r)", "Avg Rank")
  } else {
    # Fallback if column names differ
    summary_data <- importance
  }

  openxlsx::writeData(wb, "Importance Summary", summary_data, startRow = 1)
  openxlsx::addStyle(wb, "Importance Summary", header_style, rows = 1,
                     cols = 1:ncol(summary_data), gridExpand = TRUE)
  openxlsx::setColWidths(wb, "Importance Summary", cols = 1:ncol(summary_data),
                         widths = "auto")

  # ----------------------------------------------------------------------
  # Sheet 2: Detailed Rankings
  # ----------------------------------------------------------------------
  openxlsx::addWorksheet(wb, "Method Rankings")

  ranking_cols <- c("Driver", "Label", "Shapley_Rank", "RelWeight_Rank",
                    "Beta_Rank", "Corr_Rank", "Average_Rank")

  if (all(ranking_cols %in% names(importance))) {
    ranking_data <- importance[, ranking_cols, drop = FALSE]
    names(ranking_data) <- c("Driver", "Label", "Shapley Rank", "Rel. Weight Rank",
                             "Beta Rank", "Corr Rank", "Average Rank")
  } else {
    ranking_data <- importance
  }

  openxlsx::writeData(wb, "Method Rankings", ranking_data, startRow = 1)
  openxlsx::addStyle(wb, "Method Rankings", header_style, rows = 1,
                     cols = 1:ncol(ranking_data), gridExpand = TRUE)
  openxlsx::setColWidths(wb, "Method Rankings", cols = 1:ncol(ranking_data),
                         widths = "auto")

  # ----------------------------------------------------------------------
  # Sheet 3: Model Summary + VIF Diagnostics
  # ----------------------------------------------------------------------
  openxlsx::addWorksheet(wb, "Model Summary")

  model_summary <- data.frame(
    Metric = c("R-Squared", "Adj R-Squared", "F-Statistic", "P-Value", "RMSE", "N"),
    Value = c(
      summary(model)$r.squared,
      summary(model)$adj.r.squared,
      summary(model)$fstatistic[1],
      pf(summary(model)$fstatistic[1],
         summary(model)$fstatistic[2],
         summary(model)$fstatistic[3],
         lower.tail = FALSE),
      sqrt(mean(residuals(model)^2)),
      nobs(model)
    ),
    stringsAsFactors = FALSE
  )

  openxlsx::writeData(wb, "Model Summary", model_summary, startRow = 1)
  openxlsx::addStyle(wb, "Model Summary", header_style, rows = 1,
                     cols = 1:2, gridExpand = TRUE)
  openxlsx::setColWidths(wb, "Model Summary", cols = 1:2, widths = "auto")

  # Add VIF diagnostics
  tryCatch({
    vif_vals <- calculate_vif(model)
    vif_df <- data.frame(
      Driver = names(vif_vals),
      VIF = as.numeric(vif_vals),
      stringsAsFactors = FALSE
    )
    vif_df$Warning <- ifelse(vif_df$VIF > 10, "High VIF (>10)",
                             ifelse(vif_df$VIF > 5, "Moderate VIF (>5)", "OK"))

    openxlsx::writeData(wb, "Model Summary", "VIF Diagnostics",
                       startRow = nrow(model_summary) + 3, startCol = 1)
    openxlsx::writeData(wb, "Model Summary", vif_df,
                       startRow = nrow(model_summary) + 4, startCol = 1)
    openxlsx::addStyle(wb, "Model Summary", header_style,
                      rows = nrow(model_summary) + 4,
                      cols = 1:3, gridExpand = TRUE)
  }, error = function(e) {
    # VIF calculation failed - log explicitly (no silent fails per TRS)
    msg <- sprintf("VIF diagnostics failed and were skipped: %s", conditionMessage(e))
    cat(sprintf("   [WARN] %s\n", msg))
    warning(msg, call. = FALSE)
    NULL
  })

  # ----------------------------------------------------------------------
  # Sheet 4: Correlation Matrix
  # ----------------------------------------------------------------------
  openxlsx::addWorksheet(wb, "Correlations")
  cor_df <- as.data.frame(correlations)
  cor_df <- cbind(Variable = rownames(cor_df), cor_df)
  rownames(cor_df) <- NULL

  openxlsx::writeData(wb, "Correlations", cor_df, startRow = 1)
  openxlsx::addStyle(wb, "Correlations", header_style, rows = 1,
                     cols = 1:ncol(cor_df), gridExpand = TRUE)
  openxlsx::setColWidths(wb, "Correlations", cols = 1:ncol(cor_df), widths = "auto")

  # ----------------------------------------------------------------------
  # Sheet 5: Charts (Shapley impact bar chart)
  # ----------------------------------------------------------------------
  openxlsx::addWorksheet(wb, "Charts")

  if ("Shapley_Value" %in% names(importance)) {
    # Small data frame for chart
    chart_data <- importance[order(importance$Shapley_Value, decreasing = TRUE),
                             c("Driver", "Label", "Shapley_Value"), drop = FALSE]
    names(chart_data) <- c("Driver", "Label", "Shapley_Percent")

    openxlsx::writeData(wb, "Charts", chart_data, startRow = 1, startCol = 1)

    # Build the bar plot and insert it below the table
    plot_row_start <- nrow(chart_data) + 4

    # Create temporary file for plot
    plot_file <- tempfile(fileext = ".png")

    # Use Label if available, otherwise Driver
    labels <- ifelse(
      is.na(chart_data$Label) | chart_data$Label == "",
      chart_data$Driver,
      chart_data$Label
    )

    # Create and save plot
    grDevices::png(filename = plot_file, width = 800, height = 600, res = 100)
    graphics::par(mar = c(5, 14, 4, 2))  # Extra left margin for labels
    graphics::barplot(
      height = chart_data$Shapley_Percent,
      names.arg = labels,
      horiz = TRUE,
      las = 1,
      col = "#4472C4",
      xlab = "Shapley Impact (%)",
      main = "Key Driver Impact (Shapley Values)"
    )
    grDevices::dev.off()

    # Insert the saved plot
    openxlsx::insertImage(
      wb,
      sheet = "Charts",
      file = plot_file,
      startRow = plot_row_start,
      startCol = 1,
      width = 7,
      height = 5,
      units = "in"
    )

    # Note: Don't delete plot_file yet - it needs to exist until saveWorkbook() is called
    # The temp file will be cleaned up by the OS eventually
  } else {
    openxlsx::writeData(wb, "Charts",
                       "Shapley_Value column not found; chart not generated.",
                       startRow = 1, startCol = 1)
  }

  # ----------------------------------------------------------------------
  # Sheet 6: Run_Status (TRS v10.3 Output Contract)
  # ----------------------------------------------------------------------
  openxlsx::addWorksheet(wb, "Run_Status")

  # Build status table
  status_table <- data.frame(
    Field = c(
      "run_status",
      "analysis_date",
      "outcome_variable",
      "n_drivers",
      "sample_size",
      "r_squared",
      "primary_method",
      "spec_version"
    ),
    Value = c(
      run_status,
      as.character(Sys.time()),
      config$outcome_var,
      length(config$driver_vars),
      nobs(model),
      round(summary(model)$r.squared, 4),
      "partial_r2",
      "TURAS-KD-CONTINUOUS-UPGRADE-v1.0"
    ),
    stringsAsFactors = FALSE
  )

  openxlsx::writeData(wb, "Run_Status", status_table, startRow = 1)
  openxlsx::addStyle(wb, "Run_Status", header_style, rows = 1, cols = 1:2, gridExpand = TRUE)
  openxlsx::setColWidths(wb, "Run_Status", cols = 1:2, widths = c(25, 40))

  # Add degraded reasons if PARTIAL
  if (run_status == "PARTIAL" && !is.null(status_details)) {
    start_row <- nrow(status_table) + 3
    openxlsx::writeData(wb, "Run_Status", "Degraded Outputs:", startRow = start_row, startCol = 1)

    if (!is.null(status_details$degraded_reasons)) {
      deg_df <- data.frame(
        Reason = status_details$degraded_reasons,
        stringsAsFactors = FALSE
      )
      openxlsx::writeData(wb, "Run_Status", deg_df, startRow = start_row + 1, startCol = 1)
    }

    if (!is.null(status_details$affected_outputs)) {
      aff_row <- start_row + length(status_details$degraded_reasons) + 3
      openxlsx::writeData(wb, "Run_Status", "Affected Outputs:", startRow = aff_row, startCol = 1)
      aff_df <- data.frame(
        Output = status_details$affected_outputs,
        stringsAsFactors = FALSE
      )
      openxlsx::writeData(wb, "Run_Status", aff_df, startRow = aff_row + 1, startCol = 1)
    }
  }

  # Add driver-level method notes
  if ("Method_Note" %in% names(importance) || "DriverType" %in% names(importance)) {
    method_start <- if (run_status == "PARTIAL" && !is.null(status_details)) {
      nrow(status_table) + length(status_details$degraded_reasons) +
        length(status_details$affected_outputs) + 8
    } else {
      nrow(status_table) + 4
    }

    openxlsx::writeData(wb, "Run_Status", "Driver Method Notes:", startRow = method_start, startCol = 1)

    method_cols <- c("Driver")
    if ("DriverType" %in% names(importance)) method_cols <- c(method_cols, "DriverType")
    if ("AggMethod" %in% names(importance)) method_cols <- c(method_cols, "AggMethod")
    if ("Method_Note" %in% names(importance)) method_cols <- c(method_cols, "Method_Note")

    available_cols <- intersect(method_cols, names(importance))
    if (length(available_cols) > 0) {
      method_df <- importance[, available_cols, drop = FALSE]
      openxlsx::writeData(wb, "Run_Status", method_df, startRow = method_start + 1, startCol = 1)
      openxlsx::addStyle(wb, "Run_Status", header_style, rows = method_start + 1,
                        cols = 1:length(available_cols), gridExpand = TRUE)
    }
  }

  # ----------------------------------------------------------------------
  # Sheet 7: README / Methodology
  # ----------------------------------------------------------------------
  openxlsx::addWorksheet(wb, "README")

  readme_text <- c(
    "TURAS KEY DRIVER ANALYSIS - OUTPUT FILE",
    "",
    paste("Analysis Date:", Sys.Date()),
    paste("Outcome Variable:", config$outcome_var),
    paste("Number of Drivers:", length(config$driver_vars)),
    paste("Weight Variable:", ifelse(is.null(config$weight_var), "None (unweighted)", config$weight_var)),
    paste("Sample Size:", nobs(model)),
    paste("Model R-Squared:", round(summary(model)$r.squared, 3)),
    "",
    "=== IMPORTANCE METRICS ===",
    "",
    "1. Shapley Value (%)",
    "   - Game theory approach for fair R² allocation",
    "   - Considers all possible combinations of drivers",
    "   - Most robust method; recommended for prioritization",
    "",
    "2. Relative Weight (%)",
    "   - Johnson's method using orthogonal decomposition",
    "   - Handles multicollinearity well",
    "   - Always non-negative and sums to 100%",
    "",
    "3. Beta Weight (%)",
    "   - Based on absolute value of standardized regression coefficients",
    "   - Traditional approach; easy to interpret",
    "   - Can be unstable with high multicollinearity",
    "",
    "4. Beta Coefficient",
    "   - Signed standardized regression coefficient",
    "   - Shows direction of relationship (positive/negative)",
    "   - Values in standard deviation units",
    "",
    "5. Correlation (r)",
    "   - Simple Pearson correlation with outcome",
    "   - Signed value showing direction",
    "   - Does not account for other variables",
    "",
    "=== INTERPRETATION GUIDELINES ===",
    "",
    "Importance Scores:",
    "  - >20%: Major driver (high priority)",
    "  - 10-20%: Moderate driver (secondary priority)",
    "  - <10%: Minor driver (limited impact)",
    "",
    "VIF (Variance Inflation Factor):",
    "  - VIF < 5: Low multicollinearity",
    "  - VIF 5-10: Moderate multicollinearity",
    "  - VIF > 10: High multicollinearity (consider removing driver)",
    "",
    "Method Consensus:",
    "  - High consensus (all methods agree): Strong evidence",
    "  - Low consensus (methods disagree): Investigate further",
    "",
    "=== ASSUMPTIONS & LIMITATIONS ===",
    "",
    "Assumptions:",
    "  - Linear relationships between drivers and outcome",
    "  - Independent observations",
    "  - No severe multicollinearity (VIF < 10 recommended)",
    "",
    "Limitations:",
    "  - Cannot detect non-linear relationships",
    "  - Assumes additive effects (no interactions)",
    "  - Correlation ≠ causation",
    "  - Missing data handled via listwise deletion",
    "",
    "=== SHEETS IN THIS WORKBOOK ===",
    "",
    "1. Importance Summary - All importance metrics in one view",
    "2. Method Rankings - Rank positions from each method",
    "3. Model Summary - R², F-stat, RMSE, VIF diagnostics",
    "4. Correlations - Full correlation matrix",
    "5. Charts - Visual representation of driver impact",
    "6. Run_Status - TRS run status and method notes (v10.3)",
    "7. README - This documentation",
    "",
    "=== REFERENCES ===",
    "",
    "Shapley, L. S. (1953). A value for n-person games.",
    "Johnson, J. W. (2000). A heuristic method for estimating relative weights.",
    "Tonidandel, S., & LeBreton, J. M. (2011). Relative importance analysis.",
    "",
    "For questions or support, contact the Turas development team."
  )

  readme_df <- data.frame(Content = readme_text, stringsAsFactors = FALSE)
  openxlsx::writeData(wb, "README", readme_df, startRow = 1, startCol = 1,
                     colNames = FALSE)
  openxlsx::setColWidths(wb, "README", cols = 1, widths = 100)

  # Save workbook (TRS v1.0: Use atomic save if available)
  if (exists("turas_save_workbook_atomic", mode = "function")) {
    save_result <- turas_save_workbook_atomic(wb, output_file, module = "KDA")
    if (!save_result$success) {
      stop(sprintf("Failed to save Excel file: %s\nPath: %s", save_result$error, output_file), call. = FALSE)
    }
  } else {
    openxlsx::saveWorkbook(wb, output_file, overwrite = TRUE)
  }
}
