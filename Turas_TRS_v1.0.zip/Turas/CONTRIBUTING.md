# Contributing to Turas

## Code Standards

### Follow ADRs
All development must follow the Architectural Decision Records in `/docs/adr/`:
- ADR-001: Module structure standard (use `lib/` pattern)
- ADR-002: Shared utilities location (`/modules/shared/lib/`)
- ADR-003: File size guidelines (max 800 lines for feature files)
- ADR-004: No hardcoded paths (use `find_turas_root()`)
- ADR-005: Error handling patterns

### File Organization
```
/modules/{module}/
├── README.md              # Required: Module overview
├── run_{module}.R         # Headless runner
├── run_{module}_gui.R     # Shiny launcher (if applicable)
└── lib/ or R/             # R script subfolder (see note below)
    └── [feature files]    # Max 800 lines each
```

### Current Module Directory Patterns

**Note:** Modules currently use different subfolder patterns for historical reasons:

| Pattern | Modules | Notes |
|---------|---------|-------|
| `lib/` | tabs, segment, tracker | Original pattern |
| `R/` | maxdiff, keydriver, conjoint, confidence, pricing | R package convention |
| Mixed | tracker | 16 R files at root + `lib/` subfolder |

**For new modules:** Use `R/` pattern (more common, follows R package convention).

**When refactoring:** Normalize to the dominant pattern in that module.

### Shared Utilities
Use consolidated shared utilities from `/modules/shared/lib/`:

```r
# Recommended: Single import
source(file.path(find_turas_root(), "modules/shared/lib/import_all.R"))

# Or individual files (respect dependency order)
source(file.path(turas_root, "modules/shared/lib/validation_utils.R"))
source(file.path(turas_root, "modules/shared/lib/config_utils.R"))
```

### Path Handling
Never hardcode paths. Always use dynamic resolution:

```r
# Good
turas_root <- find_turas_root()
data_path <- file.path(project_root, config$data_file)

# Bad - never do this
source("/Users/someone/Turas/modules/shared/lib/utils.R")
```

## Package Management (renv)

Turas uses `renv` for reproducible package management. This ensures everyone runs identical package versions.

### First Time Setup

```r
# After cloning, restore packages from lockfile
renv::restore()
```

### Adding a Package

```r
# 1. Install
renv::install("newpackage")

# 2. Update lockfile
renv::snapshot()

# 3. Commit renv.lock
```

### After Git Pull

```r
# If renv.lock changed
renv::restore()
```

See `docs/RENV_GUIDE.md` for full documentation.

## Pull Request Process

1. **Create feature branch** from main
2. **Make changes** following code standards
3. **Run tests**: `Rscript tests/testthat.R`
4. **Sync packages**: `renv::restore()` (if renv.lock changed)
5. **Update documentation** if APIs changed
6. **Submit PR** with description of changes

## Code Review Checklist

- [ ] No hardcoded paths
- [ ] No duplicated utility functions (use shared)
- [ ] File size under 800 lines (or justified)
- [ ] Tests included for new functionality
- [ ] Documentation updated
- [ ] Error messages are actionable

## Testing

### Running Tests
```r
# All tests
Rscript tests/testthat.R

# Regression tests
Rscript tests/regression/run_all_regression_tests.R

# Specific module
Rscript tests/testthat/test_shared_weights.R
```

### Writing Tests
- Place unit tests in `/tests/testthat/`
- Place regression tests in `/tests/regression/`
- Use descriptive test names
- Test edge cases (NA, empty, invalid input)

## Reporting Issues

Use GitHub Issues with:
- Clear description of the problem
- Steps to reproduce
- Expected vs actual behavior
- R version and OS

## Questions?

See `/docs/` for additional documentation or open a discussion.
