# Turas Test Data

This folder contains synthetic test data for the Conjoint and Key Driver modules.

See `TEST_NEW_MODULES.md` for testing instructions.
